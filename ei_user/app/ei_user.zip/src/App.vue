<script>
export default {
  onLaunch: function() {},
  onShow: function() {},
  onHide: function() {},
  addGlobalClass: true,
};
</script>

<style>
/*每个页面公共css */
</style>
