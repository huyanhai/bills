<template>
  <view class="page-null">
    <van-empty description="请稍后" />
  </view>
</template>

<script>
export default {

}
</script>

<style>
</style>