export const BASE_URL = "https://pmy.funku.cn/agent/api/"; //请求地址
// export const BASE_URL = "http://88yqq.cn/agent/api/"; //请求地址


export const TIMEOUT = 30000; // ms