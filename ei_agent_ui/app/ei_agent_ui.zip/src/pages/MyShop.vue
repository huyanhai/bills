<template>
  <view class="page-myshop">
    <ShopItem
      v-for="item in shopList"
      :key="item.id"
      class="shop-item"
      :item="item"
      @itemClick="goPage(item.id)"
      @jihuo="jihuo"
    />
    <van-popup :show="showJihuo">
      <view class="jihuo-box">
        <view class="title">确认激活</view>
        <view class="tips">请确保税盘控Uk已插到联网服务器上</view>
        <van-button type="info" class="queren" :disabled="time > 0" @click="jihuoApi">
          {{ time < 1 ? '激活' : `${time}s` }}
        </van-button>
        <van-button type="warning" @click="showJihuo = false">
          取消
        </van-button>
      </view>
    </van-popup>
  </view>
</template>

<script>
import ShopItem from '../components/ShopItem.vue';
import { post, get } from '../../libs/request';

export default {
  data() {
    return {
      shopList: [],
      showJihuo: false,
      time: 3,
      id: null,
      page: 1,
      limit: 100,
    };
  },
  onShow() {
    this.getData();
  },
  methods: {
    countDown() {
      const vm = this;
      const timer = setInterval(() => {
        vm.time--;
        if (vm.time < 1) {
          clearInterval(timer);
        }
      }, 1000);
    },
    jihuo(e) {
      this.id = e;
      this.showJihuo = true;
      this.time = 3;
      this.countDown();
    },
    async jihuoApi() {
      const vm = this;
      const { code } = await get('agent/activate/account', {
        siteId: this.id,
      });
      if (code === 0) {
        uni.showToast('激活成功');
        this.showJihuo = false;
        setTimeout(() => {
          vm.getData();
        }, 2000);
      }
    },
    goPage(e) {
      uni.navigateTo({
        url: `ShopDetails?id=${e}`,
      });
    },
    async getData() {
      const { data } = await post('agent/site_info/page', {
        page: this.page,
        limit: this.limit,
        searchModel: {
          id: '',
        },
      });
      if (data) {
        this.shopList = data;
      }
    },
  },
  components: {
    ShopItem,
  },
};
</script>

<style lang="scss">
.page-myshop {
  min-height: 100vh;
  padding: 30rpx;
  background: #eee;
  box-sizing: border-box;
  .shop-item {
    margin-bottom: 30rpx;
    display: block;
  }
}
.jihuo-box {
  padding: 30rpx;
  text-align: center;
  width: 600rpx;
  .title {
    margin-bottom: 40rpx;
    font-weight: bold;
  }
  .tips {
    margin-bottom: 40rpx;
    font-size: 34rpx;
  }
  .queren {
    margin-bottom: 20rpx;
    display: block;
  }
  button {
    width: 100%;
  }
}
</style>
